//  יבוא של מונגו אותו אחד שי לנו בתקייה אחרת
const mongoose = require("mongoose");

// יצור הסכמה
const productSchema = new mongoose.Schema({
    name:String,
    price:Number
})

exports.ProductModel = mongoose.model("products", productSchema);

