//  יבוא של מונגו אותו אחד שי לנו בתקייה אחרת
const mongoose = require("mongoose");

// יצור הסכמה
const shopsSchema = new mongoose.Schema({
    cat: String,
    name: String,
    price: Number,
    image: String
})

exports.ShopsModel = mongoose.model("shop", shopsSchema);


exports.validateFood = (_reqBody) => {
    const joiSchema = Joi.object({
      cat:Joi.string().min(0).max(300).required(),
      name:Joi.string().min(2).max(300).required(),
      price:Joi.number().min(1).max(999).required(),
      img_url:Joi.string().min(2).max(500).required()
    })
    return joiSchema.validate(_reqBody)
  }

