const mongoose = require("mongoose");
const Joi = require("joi");

const foodsSchema = new mongoose.Schema({
    name:String,
    cars:Number,
    price:Number,
    img_utl:String,
    catagory_id:String,

})


exports.FoodModle = mongoose.model("foods",foodsSchema);

exports.validateFood = (_reqBody) => {
    const joiSchema = Joi.object({
      name:Joi.string().min(2).max(300).required(),
      cals:Joi.number().min(0).max(9999).required(),
      price:Joi.number().min(1).max(999).required(),
      img_url:Joi.string().min(2).max(500).required(),
      category_id:Joi.string().min(2).max(300).required(),
    })
    return joiSchema.validate(_reqBody)
  }