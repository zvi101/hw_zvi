const express = require("express");
const axios = require("axios");
const router = express.Router();


//  API בקשת
//  xbox/
router.get("/single/:index", async(req,res) => {
  try{
    const index = req.params.index;
    const url = "http://fs1.co.il/bus/xbox1.php";
    const {data} = await axios.get(url);
    res.json(data[index])
  }
  catch(err){
    console.log(err);
    res.status(502).json({err})
  }
})


//  יציג מהאינדס לפי מה שרשמנו
router.get("/", async(req,res) => {
  try{
    const url = "http://fs1.co.il/bus/xbox1.php";
    const {data} = await axios.get(url);
    const splice_ar = data.splice(0,10);
    res.json(splice_ar)

  }
  catch(err){
    res.json({msg:"error",err})
  }

})


//  יציג לפי חיפוש
// xbox/search?s=
router.get("/search", async(req,res) => {
  try{
    const searchQ = req.query.s.tolowrCase();
    const url = "http://fs1.co.il/bus/xbox1.php";
    const {data} = await axios.get(url);
    const filter_ar = data.filter(item => item.Game.tolowrCase().includes(searchQ) ||
    item.Dev.tolowrCase().includes(searchQ) )
    res.json(filter_ar);
  }
  catch(err){
    console.log(err);
    res.status(502).json({err})
  }
})


//  יציג לפי שנה
//  /xbox/years?year=2006 
router.get("/years", async(req,res) => {
  try{
    const yearQ = req.query.year;
    const url = "http://fs1.co.il/bus/xbox1.php";
    const {data} = await axios.get(url);
    const filter_ar = data.filter(item => item.Year == yearQ);
    res.json(filter_ar);

  }
  catch(err){
    console.log(err);
    res.status(502).json({err})
  }
})




module.exports = router;