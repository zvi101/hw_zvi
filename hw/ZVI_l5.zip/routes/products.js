const express = require("express");
const {ProductModel} = require("../models/productModel");
const router = express.Router();

router.get("/", async(req,res) => {
  // יחזיר את כל מה שיש במסד נתונים -> find({})
    const data = await ProductModel.find({})
  res.json(data)
})

module.exports = router;