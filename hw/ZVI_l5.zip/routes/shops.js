const express = require("express");
const {shopsModel, ShopsModel} = require("../models/shopsModel");
const router = express.Router();

router.get("/", async(req,res) => {
 const data = await shopsModel.find({});
 res.json(data);
})


// singel/:id ישלוף לפי
router.get("/singel/:id", async(req,res) => {
    try{
        const id = req.params.id;
        const data = await ShopsModel.findOne({_id:id});
        res.json(data);
    }
    catch(err){
        console.log(err);
        res.status(502).json({err})
    }
})


// category/?cat=
// שולף לפי קטגוריה
router.get("/category", async(req,res) => {
    try{
        //  שולף רשומה לפי קטגוריה
        const categoryQ = req.query.cat;
        const data = await ShopsModel.find({category_short_id:categoryQ});
        res.json(data);
    }
    catch(err){
        console.log(err);
        res.status(502).json({err})
    }
})


module.exports = router;