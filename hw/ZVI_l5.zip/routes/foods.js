const express = require("express");
const {FoodModel, validateFood } = require("../models/foodModel")
const router = express.Router();


// יציג הכל
router.get("/", async(req,res) => {
  try{
    const data = await FoodModel.find({});
    res.json(data);
  }
  catch(err){
    console.log(err);
    res.status(502).json({err})
  }
})


// ID שליפה לפי 
// /foods/single/635e69c1f0d7593da60ffe2e
router.get("/single/:id", async(req,res) => {
  try{
    const id = req.params.id;
    const data = await FoodModel.find({_id:id});
    res.json(data);
  }
  catch(err){
    console.log(err);
    res.status(502).json({err})
  }
})


// שליפה לפי קטגוריה
//  /foods/category?cat=Italy
router.get("/category", async(req,res) =>{
  try{
    const catQ = req.query.cat;
    const data = await FoodModel.find({category_id:catQ});
    res.json(data);
  }
  catch(err){
    console.log(err);
    res.status(502).json({err})
  }
})


// שליפה לפי חיפוש
// מספיק חצי שם
// /foods/search?s=pie
router.get("/search", async(req,res) => {
  try{
    const searchQ = req.query.s;
    // ביטוי רגולארי בשביל לחיפוש
    const searchReg = new RegExp(searchQ);
    const data = await FoodModel.find({name:searchReg});
    res.json(data);
  }
  catch(err){
    console.log(err);
    res.status(502).json({err})
  }
})


// post //
router.post("/",async(req,res) =>{
  // בודק שהמידע שהגיע מהבאדי תקין
  let validBody = validateFood(req.body);
  // בודק אם יש מאפיין אירור שמרמז על טעות בבאדי
  if(validBody.error){
    // סטטוס שגיאה מצד לקוח - 400
    return res.status(400).json(validBody.error.details);
  }
  try{
    // req.body -> שולח כגייסון בצד לקוח/פוסטמן 
      const food = new FoodModel(req.body);
    // מבצע את הפעולת ההוספה רשומה
    await food.save();
    res.json(food)
  }
  catch(err){
    console.log(err);
    res.status(502).json({err})
  }
})




module.exports = router;