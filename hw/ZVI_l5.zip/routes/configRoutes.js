const indexR = require("./index");
const usersR = require("./users");
const xboxR = require("./xboxGames");
const productsR = require("./products");
const foodsR = require("./foods");
const shopsR = require("./shops")


exports.routesInit = (app) => {
  app.use("/", indexR);
  app.use("/users", usersR);
  app.use("/xbox",xboxR);
  app.use("/products", productsR);
  app.use("/foods",foodsR);
  app.use("/shops",shopsR);

}

