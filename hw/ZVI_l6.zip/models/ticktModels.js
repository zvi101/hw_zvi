const mongoose = require("mongoose");
const Joi = require("joi");

// לסכמה אין השפעה על בקשת פיינד של מונגו
// אבל יש השפעה כאשר מוסיפים רשומה או עורכים של קיים פה
const ticketSchmema = new mongoose.Schema({
    name:String,
    info:String,
    price:Number,
    category_short_id:Number,
    location:String
})

exports.TicketModel = mongoose.model("tickets", ticketSchmema);


exports.validateTicket = (_reqBody) => {
    const joiSchema = Joi.object({
      name:Joi.string().min(2).max(200).required(),
      info:Joi.string().min(2).max(400).required(),
      price:Joi.number().min(1).max(999999).required(),
      category_short_id:Joi.number().min(1).max(999999).required(),
      // לוקשיין לא חובה לשלוח
      // .allow(null,"") -> מאפשר לשלוח סרטינג ריק
      location:Joi.string().min(2).max(200).allow(null,"")
  
    })
    return joiSchema.validate(_reqBody);
  }