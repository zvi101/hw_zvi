const mongoose = require("mongoose");
const Joi = require("joi");

const cakeSchmema = new mongoose.Schema({
    name:String,
    cals:Number,
    price:Number,
    img_url:String
})

exports.CakeModle = mongoose.model("cakes", cakeSchmema);

exports.validateCake = (_reqBody) => {
    const joiSchema = Joi.object({
      name:Joi.string().min(2).max(200).required(),
      cals:Joi.number().min(1).max(999).required(),
      price:Joi.number().min(1).max(99999).required(),
    })
    return joiSchema.validate(_reqBody);
  }