const mongoose = require("mongoose");
const Joi = require("joi");

const productSchmema = new mongoose.Schema({
    name:String, 
    price:Number,

})

exports.ProductModel = mongoose.model("products", productSchmema);


exports.validateProduct = (_reqBody) => {
    const joiSchema = Joi.object({
      name:Joi.string().min(2).max(300).required(),
      price:Joi.number().min(1).max(999).required(),
      // לוקשיין לא חובה לשלוח
      // .allow(null,"") -> מאפשר לשלוח סרטינג ריק
      location:Joi.string().min(2).max(200).allow(null,"")
  
    })
    return joiSchema.validate(_reqBody);
  }