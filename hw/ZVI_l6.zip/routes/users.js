const express = require("express");
const bcrypt = require("bcrypt");
const router = express.Router();

router.get("/", async(req,res) => {
  res.json({msg:"user work 77777"})
})

// localhost:3001/users/showInfo
router.get("/showInfo", async(req,res) => {
  res.json({msg:"Show info"})
})


// 
router.post("/", async(req,res) => {
  // בודק שהבאדי שנשלח מצד הלקוח תקין לפי הסכימה
  const validBody = validateUser(req.body)
  if(validBody.error){
    return res.status(400).json(validBody.error.details)
  }
  try{
    const user = new UserModel(req.body);
    user.password = await bcrypt.hash(user.password,10)
    await user.save();
    // 201 -> שיש הצלחה ונוספה רשומה
    res.status(201).json(user)
  }
  catch(err){
    console.log(err);
    res.status(502).json({err})
  }
})

module.exports = router;