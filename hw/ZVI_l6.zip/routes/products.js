const express = require("express");
const { ProductModel, validateProduct} = require("../models/productModels");
const {join} = require("lodash");
const router = express.Router();


// -> בקשת גאט יחזיר את כל הרשומות
// localhost:3001/products
router.get("/", async(req,res) => {
  //res.json({msg:"product work!"})
  try{
    const data = await ProductModel.find({});
    res.json(data);
  }
  catch(err){
    console.log(err);
    res.status(502).json({err})
  }
})


// -> הוספת רשומה דרך הפוסט מן
router.post("/", async(req,res) => {
    const validBody = validateProduct(req.body)
    if(validBody.error){
        return res.status(400).json(validBody.error.details)
    }
    try{
        // -> הוספת רשומה חדשה ולשמור במסד נתונים
        let product = new ProductModel(req.body);
        await product.save()
        res.json(product);

    }
    catch(err){
        console.log(err);
        res.status(502).json({err})
    }
})


module.exports = router;