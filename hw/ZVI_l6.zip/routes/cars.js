const express = require("express");
const axios = require("axios");
const router = express.Router();


// ש.ב. של שיעור 4

// -> יחזיר 30 רכבים
// cars?page=number
router.get("/", async(req,res) => {
  try{
    // ההגבלה פר בקשה של תצוגת פריטים
    const limit = 10;
    // || - אם לא נכון יחזיר את מה שכתוב מצד ימין שלו
    const page = req.query.page - 1 || 0;
    const url = "https://myfakeapi.com/api/cars";
    const {data} = await axios.get(url);
    const splice_ar = data.cars.splice(page * limit,limit);
    res.json(splice_ar);
  }
  catch(err){
    console.log(err);
    res.status(502).json({err})
  }
})


// -> יחזיר לפי שם החברה
// cars/company?company= 
router.get("/company", async(req,res) => {
  try{
    const url = "https://myfakeapi.com/api/cars";
    const {data} = await axios.get(url);
    const companyQ = req.query.company;
    // -> עדיין נעשה פילטר שיציג עד מספר מסוים
    const companies_ar = data.cars.filter(item => {
      return item.car == companyQ
    }) 
    // יחזיר מתא 0 , 20 תאים קדימה
    const slice_ar = companies_ar.slice(0,20);
    res.json(slice_ar);
  }
  catch(err){
    console.log(err);
    res.status(502).json({err})
  }
})


module.exports = router;