const express = require("express");
const {CakeModle, validateCake} = require("../models/cakeModels");
const { join } = require("lodash");
const router = express.Router();



// limit and skip
// and sort
router.get("/",async(req,res) => {
    let perpage = req.query.perpage ? Math.min( req.query.perpage, 5) : 3;
    let page = req.query.page ? req.query.page -1 : 0;
    // לאסוף לפי מאפיין 
    let sort = req.query.sort || "_id";
    try{
        const data = await CakeModle
        .find({})
        .limit(perpage)
        .skip(page * perpage)
        .sort({[sort]:1})
        res.json(data);
    }
    catch(err){
        console.log(err);
        res.status(502).json({err})
    }
})


// -> מיון ליפ מחיר של מאקס ומינ
// /cakes/price?min=&max=
router.get("/price", async(req,res) => {
    try{
      const max = req.query.max || 0;
      const min = req.query.min || Infinity;
      
      const data = await CakeModle.find({price:{$lte:max, $gte:min}});
      res.json(data);
    }
    catch(err){
      console.log(err);
      res.status(502).json({err})
    }
  })


  // הוספה של רשומה
router.post("/", async(req,res) => {
  const validBody = validateCake(req.body)
  if(validBody.error){
      return res.status(400).json(validBody.error.details)
  }
  try{
    const cake = new CakeModle(req.body);
    await cake.save()
    res.json(cake)
  }
  catch(err){
      console.log(err);
      res.status(502).json({err})
  }
})


module.exports = router;