const indexR = require("./index");
const usersR = require("./users");
const carsR = require("./cars");
const ticketsR = require("./tickets");
const productsR = require("./products")
const cakesR = require("./cakes");


exports.routesInit = (app) => {
  app.use("/", indexR);
  app.use("/users", usersR);
  app.use("/cars",carsR);
  app.use("/tickets", ticketsR);
  app.use("/products", productsR);
  app.use("/cakes", cakesR);

}

