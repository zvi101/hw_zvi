const express = require("express");
const {TicketModel, validateTicket} = require("../models/ticktModels");
const { default: axios } = require("axios");
const router = express.Router();



// -> localhost:3001/tickets
// tickets?page=&sort=
router.get("/", async(req,res) => {
  try{
    // -> limit() = כמה יציג לנו מהרשומות
    // -> skip() = על כמה רשומות נדלג
    // -> sort() = מיון: 1 מיצג מהנמוך לגבוה 2 מהגבוה לנמוך
    // -> reverse = 
    const limit=5;
    // נוכל לכתוב בקווארי סטרינג
    const page = req.query.page -1 || 0;
    const sort = req.query.sort || "_id";  // נוכל לבחור איזה סוג מאפיין גם דרך הקווארי
    const reve = req.query.reverse == "yes" ? 1 : -1;

    const data = await TicketModel
    .find({})
    .limit(limit)
    .skip(page * limit)
    .sort({[sort]:reve})
    res.json(data);
  }
  catch(err){
    console.log(err);
    res.status(502).json({err})
  }
})


// יציג רשומה אחת לפי אי די
// /tickets/single/:id
router.get("/singel/:id", async(req,res) => {
  try{
      const id = req.params.id;
      // ישלוף רק פריט לפי האיי די שהעברנו בכתובת
      const data = await TicketModel.findOne({_id:id});
      res.json(data);
  }
  catch(err){
      console.log(err);
      res.status(502).json({err})
  }
})


//  שולף רשומה לפי קטגוריה
// /tickets/category/?cat=
router.get("/category", async(req,res) => {
  try{
      const categoryQ = req.query.cat;
      const data = await TicketModel.find({category_short_id:categoryQ});
      res.json(data);
  }
  catch(err){
      console.log(err);
      res.status(502).json({err})
  }
})


// הוספת רשומהה חדשה
// -> דרך הפוסט מן
// -> http://localhost:3001/tickets צריך להכניס את הקישור הזה שידע לאיזה קולקשיין
router.post("/", async(req,res) => {
    // בודק שהבאדי שהגיע מהצד לקוח תקין
    const validBody = validateTicket(req.body);
    if(validBody.error){
        return res.status(400).json(validBody.error.details)
    }
    try{
         //להחזיר מה שכתבנו
        // res.json(req.body);

        // כדי לשמור רשומה חדשה
        let ticket = new TicketModel(req.body);
        await ticket.save()
        res.json(ticket);
    }
    catch(err){
        console.log(err);
        res.status(502).json({err})
    }
})


// info שליפת רשומה לפי שם או 
// search/?s=
router.get("/search",async(req,res) => {
  try{
    const searchQ = req.query.s;
    // הופכים לביטוי רגולרי כדי שנוכל לבצע חיפוש
    // i - כדי שלא תיהיה בעיית קייס סינסטיב, אות גדולה או קטנה
    const searchExp = new RegExp(searchQ,"i")

    // נשלוף את הרשומות שחיפשנו
    // $or -> פקודה מיוחד של פיינד , שמאפשר לעשות שאילתא שבודקת בכמה מאפיינים
    const data = await TicketModel.find({$or:[{name:searchExp},{info:searchExp}]});
    res.json(data);
  }
  catch(err){
    console.log(err);
    res.status(502).json({err})
  }
})


// -> מיון ליפ מחיר של מאקס ומינ
// /tickets/price?min=&max=
router.get("/price", async(req,res) => {
  try{
    // נשלוף רשומות לפי קטגוריה
    const max = req.query.max || 0;
    const min = req.query.min || Infinity;  // Infinity -> אין סוף

    // -> !פקודות מיוחדות של נוד מתחיל בדולר
    // $lte -> lower then or Equal קטן או שווה
    // $gte -> greater then or Equal גדול או שווה
    const data = await TicketModel.find({price:{$lte:max, $gte:min}});
    res.json(data);
  }
  catch(err){
    console.log(err);
    res.status(502).json({err})
  }
})



module.exports = router;