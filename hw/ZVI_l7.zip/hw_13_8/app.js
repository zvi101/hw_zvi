const express = require("express");

const http = require("http");
const {routesInit} = require("./routs/configRoutes");
require("./db/mongoConact");

const app = express();
app.use(express.json());
routesInit(app);

const server = http.createServer(app);

const port = process.env.PORT || 3002;

server.listen(port);
