//console.log("app work");

// ספריית אקספאס עם כל היכולות
const express = require("express");
// מצבע מיפוךציות על כתובות אינטרנט
const path = require("path");
// ספריה שיודעת להפעיל שרת
const http = require("http");

const {routerInit} = require("./routes/configRoutes")


// const indxR = require("./routes/indx");
// const usersR = require("./routes/users");



// משתנה שייצג את כל היכולות והתוספות 
// שנרצה להכניס לאקספרס
const app = express();


// מיידל וואר מגדיר פונקצית אמצע -> use

// מגדיר שתקיית פאבליק וכל הקבצים בה יהיו ציבוריים 
app.use(express.static(path.join(__dirname, "public")));

routerInit(app);
// הגדרה ראונית של ראות בשרת
// app.use("/",indxR);
// app.use("/users",usersR);


// app.use("/", (req,res) => {
//     res.send("Express work 23076");
// })

const server = http.createServer(app);

// בודק באיזה פורט להריץ את השרת  , אם בשרת אמיתי אוסף
// את המשתנה פורט מהסביבת עבודה שלו ואם לא 3001
const port = process.env.PORT || 3001;
server.listen(port)
