
const express = require("express");
const {vip_ar} = require("../data/vipJson")
const router = express.Router();

router.get("/", async(req,res) => {
  // res.json({msg:"vip work!"})
  res.json(vip_ar);
})


//  / -> נקראה פארמס
//  : -> מרמז שהאינדקס הוא משתנה פארמס ולא סטטי
//  localhost:3001/vip/single/<index>
router.get("/single/:index",async(req,res) => {
  const index = req.params.index;
  res.json(vip_ar[index])

  // res.json({msg:"your index:"+req.params.indx})
})


//  ? -> נקראה קווארי סטרינג
//  vip/search?s=name
router.get("/search",async(req,res) => {
  // מאפשר לאסוף את הקווארי סטרינג אס
  // ?s=
  const searchQ = req.query.s;
  // toLowerCase() -> דואג שלא תיהיה בעיה של קייס
  // סיסנטיב/אותיות גדולות קטנות
  const filter_ar = vip_ar.filter(item => {
    return item.name.toLowerCase().includes(searchQ.toLowerCase()) 
  })
  res.json(filter_ar);
 // res.json({msg:"search for "+searchQ})
})

module.exports = router;