// אתחול של כל הראותים

const indxR = require("./indx");
const usersR = require("./users");
const vipR = require("./vip");
const shopR = require("./shop");
const tvsR = require("./tvs");
const carR = require("./cars");



exports.routerInit = (app) =>{
    app.use("/",indxR);
    app.use("/users",usersR);
    app.use("/vip",vipR);
    app.use("/shop",shopR);
    app.use("/tvs",tvsR);
    app.use("/cars",carR);
    
}

