const express = require("express");
const router = express.Router();


router.get("/",async(req,res) => {
   // API סטטי
   res.json({msg:"user work 1234!!!"})
})


// localhost:3001/users/showInfo
router.get("/showInfo",async(req,res) => {
    res.json({msg:"show info!"})
 })

module.exports = router;