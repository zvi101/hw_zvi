const express = require("express");
const axios = require("axios");
const router = express.Router();



// בקשת api
// ישלוף רק 30 רכבים
//  localhost:3001/cars
router.get("/", async (req, res) => {
    try {
        const url = "https://myfakeapi.com/api/cars";
        const { data } = await axios.get(url);
       const splice_ar = data.cars.splice(0,30);
        res.json(splice_ar);
    }
    catch (err) {
        console.log(err);
        res.json({ msg: "error", err })
    }
})


//  שליפה לפי החברה 
//  localhost:3001/cars/company?company=name
router.get("/company", async (req, res) => {
    try {
        const compQ = req.query.company;
        const url = "https://myfakeapi.com/api/cars";
        const { data } = await axios.get(url);
     //   console.log(compQ);
        const filter_ar = data.cars.filter(item => item.car == compQ);
        const splice_ar = filter_ar.splice(0,10);
      //  console.log(splice_ar);
        res.json(splice_ar);
    }
    catch (err) {
        // console.log(err);
        res.json({ msg: "error", err })
    }
})


//  שליפה לפי צבע
router.get("/colors/:color", async (req, res) => {
    try {
        const colorQ = req.params.color;
        const url = "https://myfakeapi.com/api/cars";
        const { data } = await axios.get(url);
        console.log(data.cars);
        const filter_ar = data.cars.filter(item => item.car_color == colorQ);
        const splice_ar = filter_ar.splice(0,10);
        console.log(splice_ar);
        res.json(splice_ar);
    }
    catch (err) {
        // console.log(err);
        res.json({ msg: "error", err })
    }
})



module.exports = router;
