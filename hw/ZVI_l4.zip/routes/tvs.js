const express = require("express");
const  axios = require("axios");
const router = express.Router();


// :למה לעשות בקשות אקסיוס בצד שרת
// 1. סודיות מה שנמצא בקבצי גיי אס של נוד לא נגיש לצד לקוח
// 2. ניתן באיי פי איי שמחזיר המון פריטים
// 3. להפחית את כמות ואף לעשות פגניישין
// 4. איי פי איי שהוא קצת מורכב , של אובייקט בתוך אובייקט
// 5. לשלוף אותו בהרבה יותר נוחות לצד לקוח



//  וגם הצגה API בקשת
//  localhost:3001/tvs
router.get("/",async(req,res) => {
    try{
        const url ="http://fs1.co.il/bus/tv.php";
        const {data} = await axios.get(url);
        res.json(data);
    }
catch(err){
    console.log(err);
    // res.json({msg:"error",err:err}) כתוב פעמיים arr:arr
    res.json({msg:"error",err})  // וזה שווה לזה
  }
})


//  חיפוש לפי הסוג ושליפה
//  localhost:3001/tvs/kind?kind=name
router.get("/kind", async (req,res) => {
    try {
        const kindQ = req.query.kind;
        const url = "http://fs1.co.il/bus/tv.php";
        const {data} = await axios.get(url);

        const filter_ar = data.filter(item => {
            return item.kind == kindQ
        })
        res.json(filter_ar);
    }
    catch(err){
        console.log(err);
        res.json({msg:"error",err})
      }
})


module.exports = router;