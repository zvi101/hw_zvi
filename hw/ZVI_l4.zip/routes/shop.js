const express = require("express");
const {shop_ar} = require("../data/shopjson");
const router = express.Router();

router.get("/",async(req,res) => {
   // API סטטי
   res.json({shop_ar})
})


//  אפשרות לשלוף פריט פארמס מהסינגל
//  /single/:index
router.get("/single/:index",async(req,res) =>{
    //  אוסף את הפארמס אינדקס מהיו אר אל
    const index = req.params.index;
    res.json(shop_ar[index]) // מחזיר גיסון במיקום האינדאס
})


// shop/caregory?cat=
router.get("/category", async(req,res) => {
    // ?cat= אוסף את המשתנה קווארי סטרינג
    const catQ = req.query.cat;
    // לסנן רק את המוצרים שהקטגוריה שלהם שוהה לקטגוריה שאספנו מאקווארי 
    const filter_ar = shop_ar.filter(item => item.cat == catQ);
    res.json(filter_ar)
  })

module.exports = router;

